self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "80927985582b709e961ca42e5023a7ab",
    "url": "/index.html"
  },
  {
    "revision": "c642019213cfe490a923",
    "url": "/static/css/main.5f361e03.chunk.css"
  },
  {
    "revision": "445b8d1e288aff8f607b",
    "url": "/static/js/2.8690a8ec.chunk.js"
  },
  {
    "revision": "9b708f14a78503a797d30a1e817c0b57",
    "url": "/static/js/2.8690a8ec.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c642019213cfe490a923",
    "url": "/static/js/main.36d90c5c.chunk.js"
  },
  {
    "revision": "11797894d04c74f150b0",
    "url": "/static/js/runtime-main.1d1d4867.js"
  }
]);